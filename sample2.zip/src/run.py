import shutil
from pathlib import Path
from tempfile import NamedTemporaryFile
from zipfile import ZipFile

from typing import List

from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse

app = FastAPI()


def create_zip(files_path, name="sample2.zip"):
    # Create a ZipFile Object
    with ZipFile(name, 'w') as zipObj2:
        # Add multiple files to the zip
        for path in files_path:
            zipObj2.write(path)


def save_upload_file_tmp(upload_file):
    try:
        suffix = Path(upload_file.filename).suffix
        # TODO: move this to a new dir instead of /tmp
        with NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            shutil.copyfileobj(upload_file.file, tmp)
            tmp_path = Path(tmp.name)
    finally:
        upload_file.file.close()
    return tmp_path

@app.post("/files/")
async def create_files(files: List[bytes] = File(...)):
    return {"file_sizes": [len(file) for file in files]}


@app.post("/uploadfiles/")
async def create_upload_files(files: List[UploadFile] = File(...)):
    paths = []
    for file in files:
        paths.append(save_upload_file_tmp(files[0]))

    create_zip(paths)
    # Do something with paths... .zip..hash
    return {"filenames": [file.filename for file in files]}


@app.get("/")
async def main():
    content = """
        <body>
        <form action="/files/" enctype="multipart/form-data" method="post">
        <input name="files" type="file" multiple>
        <input type="submit">
        </form>
        <form action="/uploadfiles/" enctype="multipart/form-data" method="post">
        <input name="files" type="file" multiple>
        <input type="submit">
        </form>
        </body>
    """
    return HTMLResponse(content=content)